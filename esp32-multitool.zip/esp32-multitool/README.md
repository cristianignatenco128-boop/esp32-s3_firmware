# ESP32-S3 Multitool — ES3C35P edition

A touchscreen "multi-tool" menu firmware for the LCDWIKI **ES3C35P** board
(ESP32-S3-N16R8, 320×480 ST77922 QSPI display, capacitive touch). Built with
ESP-IDF + LVGL. Scope is intentionally limited to passive/read-only and
local-device tools — no network attacks, jamming, spoofing or credential
harvesting.

## Tools included

- **Wi-Fi Scanner** — lists nearby APs (SSID, channel, RSSI, security). Passive scan, never connects or transmits deauth frames.
- **BLE Scanner** — passive BLE observer; lists nearby advertisers (address, RSSI, name if advertised).
- **RGB LED** — color sliders driving the onboard addressable LED (GPIO40).
- **Clock** — live clock, with an optional one-tap SNTP sync once you're on Wi-Fi.
- **Settings** — backlight brightness (PWM on GPIO41) and basic device info.

## Build

1. Install [ESP-IDF v5.1+](https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/get-started/index.html) and `. ./export.sh` (or use the VS Code / CLion ESP-IDF extension).
2. From this folder:
   ```
   idf.py set-target esp32s3
   idf.py build
   ```
   The first build downloads the managed components listed in `main/idf_component.yml`
   (display driver, touch driver, LVGL, esp_lvgl_port, led_strip).
3. Put the board in download mode (hold **BOOT**, tap **RESET**, release **BOOT**) and flash:
   ```
   idf.py -p /dev/ttyACM0 flash monitor
   ```
   (Windows: use the COM port shown in Device Manager instead of `/dev/ttyACM0`.)

## Hardware notes / things to double-check

- **Pin mapping** lives entirely in `main/board_config.h`, taken from the
  vendor's official pin-allocation table. If your board revision differs,
  that's the only file to edit.
- **Touch controller**: the vendor documentation confirms a capacitive touch
  IC on the shared I2C bus (SDA=38, SCL=39, RST=48, INT=47) but doesn't name
  the exact part number. This firmware defaults to **CST816S/CST820**-style
  register access, which is the common choice for this class of board. If
  touch doesn't respond, the display will still work — check the serial log
  for a warning, and check the schematic PDF on the product wiki page to
  confirm the real touch IC, swapping in a different `esp_lcd_touch_*`
  component if needed.
- **LCD reset** is tied to the shared `EN` pin rather than its own GPIO, so
  there's no independent software reset for the panel — this matches the
  vendor schematic, not an oversight.
- **Wi-Fi scan blocks the UI briefly** (a second or two) while it runs,
  since it's implemented as a simple blocking call for clarity. If you want
  a fully non-blocking scan, move `esp_wifi_scan_start` into its own
  FreeRTOS task and post results back to the UI via a queue.

## Extending it

Each tool is one `ui_*.c` file with a `_screen_show()` entry point registered
from `ui_menu.c`. Adding a new tile is: write a new `ui_yourtool.c/.h` pair,
add a `make_tile(...)` call in `ui_menu.c`, and declare the show function in
`ui_menu.h`.
