#pragma once
#include "lvgl.h"
#include "led_strip.h"

// Build the main menu on the given display and show it.
void ui_menu_create(lv_disp_t *disp);

// Called by each tool screen's "Back" button.
void ui_menu_show(void);

// Screens, one per tool (each builds its own lv_obj_t screen and shows it).
void ui_wifi_screen_show(void);
void ui_ble_screen_show(void);
void ui_led_screen_show(void);
void ui_clock_screen_show(void);
void ui_settings_screen_show(void);

// Shared board handles used by tool screens.
extern led_strip_handle_t g_rgb_led;
void board_set_backlight_pct(uint8_t pct);
void board_wifi_init(void);
void board_ble_init(void);
