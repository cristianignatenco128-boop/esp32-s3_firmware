#include <string.h>
#include "esp_wifi.h"
#include "esp_log.h"
#include "ui_menu.h"

static const char *TAG = "ui_wifi";

static lv_obj_t *s_screen = NULL;
static lv_obj_t *s_list = NULL;
static lv_obj_t *s_status = NULL;

static const char *auth_mode_str(wifi_auth_mode_t m)
{
    switch (m) {
        case WIFI_AUTH_OPEN: return "open";
        case WIFI_AUTH_WEP: return "WEP";
        case WIFI_AUTH_WPA_PSK: return "WPA";
        case WIFI_AUTH_WPA2_PSK: return "WPA2";
        case WIFI_AUTH_WPA_WPA2_PSK: return "WPA/WPA2";
        case WIFI_AUTH_WPA3_PSK: return "WPA3";
        default: return "secured";
    }
}

static void run_scan_and_populate(void)
{
    lv_obj_clean(s_list);
    lv_label_set_text(s_status, "Scanning...");
    lv_refr_now(NULL);

    board_wifi_init();

    const wifi_scan_config_t scan_cfg = { .show_hidden = true };
    esp_err_t err = esp_wifi_scan_start(&scan_cfg, true /* block */);
    if (err != ESP_OK) {
        lv_label_set_text_fmt(s_status, "Scan failed (0x%x)", err);
        return;
    }

    uint16_t num = 0;
    esp_wifi_scan_get_ap_num(&num);
    if (num == 0) {
        lv_label_set_text(s_status, "No networks found");
        return;
    }

    wifi_ap_record_t *records = calloc(num, sizeof(wifi_ap_record_t));
    if (!records) {
        lv_label_set_text(s_status, "Out of memory");
        return;
    }
    esp_wifi_scan_get_ap_records(&num, records);

    char line[96];
    for (int i = 0; i < num; i++) {
        snprintf(line, sizeof(line), "%-20s  ch%-2d  %4ddBm  %s",
                  records[i].ssid[0] ? (char *)records[i].ssid : "(hidden)",
                  records[i].primary, records[i].rssi, auth_mode_str(records[i].authmode));
        lv_obj_t *btn = lv_list_add_btn(s_list, LV_SYMBOL_WIFI, line);
        lv_obj_set_style_text_font(btn, &lv_font_montserrat_14, 0);
    }
    free(records);
    lv_label_set_text_fmt(s_status, "%d networks found", num);
}

static void scan_btn_cb(lv_event_t *e)
{
    (void)e;
    run_scan_and_populate();
}

static void back_btn_cb(lv_event_t *e)
{
    (void)e;
    ui_menu_show();
}

void ui_wifi_screen_show(void)
{
    if (!s_screen) {
        s_screen = lv_obj_create(NULL);
        lv_obj_set_style_bg_color(s_screen, lv_color_hex(0x0d1117), 0);

        lv_obj_t *back = lv_btn_create(s_screen);
        lv_obj_align(back, LV_ALIGN_TOP_LEFT, 8, 8);
        lv_obj_add_event_cb(back, back_btn_cb, LV_EVENT_CLICKED, NULL);
        lv_obj_t *back_lbl = lv_label_create(back);
        lv_label_set_text(back_lbl, LV_SYMBOL_LEFT " Menu");

        lv_obj_t *scan = lv_btn_create(s_screen);
        lv_obj_align(scan, LV_ALIGN_TOP_RIGHT, -8, 8);
        lv_obj_add_event_cb(scan, scan_btn_cb, LV_EVENT_CLICKED, NULL);
        lv_obj_t *scan_lbl = lv_label_create(scan);
        lv_label_set_text(scan_lbl, LV_SYMBOL_REFRESH " Scan");

        s_status = lv_label_create(s_screen);
        lv_obj_set_style_text_color(s_status, lv_color_white(), 0);
        lv_obj_align(s_status, LV_ALIGN_TOP_MID, 0, 16);
        lv_label_set_text(s_status, "Tap Scan to search");

        s_list = lv_list_create(s_screen);
        lv_obj_set_size(s_list, lv_pct(96), lv_pct(76));
        lv_obj_align(s_list, LV_ALIGN_BOTTOM_MID, 0, -8);
    }
    lv_disp_load_scr(s_screen);
}
