#include "esp_system.h"
#include "esp_chip_info.h"
#include "ui_menu.h"

static lv_obj_t *s_screen = NULL;

static void brightness_cb(lv_event_t *e)
{
    lv_obj_t *slider = lv_event_get_target(e);
    int32_t val = lv_slider_get_value(slider);
    board_set_backlight_pct((uint8_t)val);
}

static void back_btn_cb(lv_event_t *e) { (void)e; ui_menu_show(); }

void ui_settings_screen_show(void)
{
    if (!s_screen) {
        s_screen = lv_obj_create(NULL);
        lv_obj_set_style_bg_color(s_screen, lv_color_hex(0x0d1117), 0);
        lv_obj_set_flex_flow(s_screen, LV_FLEX_FLOW_COLUMN);
        lv_obj_set_flex_align(s_screen, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
        lv_obj_set_style_pad_row(s_screen, 16, 0);
        lv_obj_set_style_pad_top(s_screen, 60, 0);

        lv_obj_t *back = lv_btn_create(s_screen);
        lv_obj_align(back, LV_ALIGN_TOP_LEFT, 8, 8);
        lv_obj_add_event_cb(back, back_btn_cb, LV_EVENT_CLICKED, NULL);
        lv_obj_t *back_lbl = lv_label_create(back);
        lv_label_set_text(back_lbl, LV_SYMBOL_LEFT " Menu");

        lv_obj_t *bl_label = lv_label_create(s_screen);
        lv_label_set_text(bl_label, "Backlight brightness");
        lv_obj_set_style_text_color(bl_label, lv_color_white(), 0);

        lv_obj_t *slider = lv_slider_create(s_screen);
        lv_obj_set_width(slider, lv_pct(80));
        lv_slider_set_range(slider, 5, 100);
        lv_slider_set_value(slider, 100, LV_ANIM_OFF);
        lv_obj_add_event_cb(slider, brightness_cb, LV_EVENT_VALUE_CHANGED, NULL);

        esp_chip_info_t info;
        esp_chip_info(&info);
        char buf[96];
        snprintf(buf, sizeof(buf), "ESP32-S3 multitool\n%d CPU core(s), rev v%d.%d",
                 info.cores, info.revision / 100, info.revision % 100);
        lv_obj_t *info_label = lv_label_create(s_screen);
        lv_label_set_text(info_label, buf);
        lv_obj_set_style_text_color(info_label, lv_color_hex(0x8ca0b3), 0);
        lv_obj_set_style_text_align(info_label, LV_TEXT_ALIGN_CENTER, 0);
    }
    lv_disp_load_scr(s_screen);
}
