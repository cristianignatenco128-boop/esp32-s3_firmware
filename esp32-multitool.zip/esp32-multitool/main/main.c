#include <stdio.h>
#include "esp_log.h"
#include "esp_err.h"
#include "nvs_flash.h"
#include "driver/spi_master.h"
#include "driver/i2c.h"
#include "driver/ledc.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_panel_vendor.h"
#include "esp_lcd_st77922.h"
#include "esp_lcd_touch.h"
#include "esp_lcd_touch_cst816s.h"
#include "esp_lvgl_port.h"
#include "led_strip.h"
#include "esp_wifi.h"
#include "esp_netif.h"
#include "esp_event.h"
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"

#include "board_config.h"
#include "ui_menu.h"

static const char *TAG = "multitool";

#define LCD_SPI_HOST   SPI2_HOST
#define BACKLIGHT_LEDC_TIMER   LEDC_TIMER_0
#define BACKLIGHT_LEDC_CHANNEL LEDC_CHANNEL_0
#define BACKLIGHT_LEDC_MODE    LEDC_LOW_SPEED_MODE
#define BACKLIGHT_LEDC_FREQ_HZ 5000
#define BACKLIGHT_LEDC_RES     LEDC_TIMER_10_BIT

led_strip_handle_t g_rgb_led = NULL;
static lv_disp_t *s_disp = NULL;

// ---------------------------------------------------------------------------
// Backlight (PWM on IO41 so brightness can be adjusted from Settings)
// ---------------------------------------------------------------------------
static void backlight_init(void)
{
    const ledc_timer_config_t timer_cfg = {
        .speed_mode = BACKLIGHT_LEDC_MODE,
        .timer_num = BACKLIGHT_LEDC_TIMER,
        .duty_resolution = BACKLIGHT_LEDC_RES,
        .freq_hz = BACKLIGHT_LEDC_FREQ_HZ,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&timer_cfg));

    const ledc_channel_config_t ch_cfg = {
        .gpio_num = BOARD_LCD_BL,
        .speed_mode = BACKLIGHT_LEDC_MODE,
        .channel = BACKLIGHT_LEDC_CHANNEL,
        .timer_sel = BACKLIGHT_LEDC_TIMER,
        .duty = (1 << BACKLIGHT_LEDC_RES) - 1, // full brightness at boot
        .hpoint = 0,
    };
    ESP_ERROR_CHECK(ledc_channel_config(&ch_cfg));
}

void board_set_backlight_pct(uint8_t pct)
{
    if (pct > 100) pct = 100;
    uint32_t max_duty = (1 << BACKLIGHT_LEDC_RES) - 1;
    uint32_t duty = (max_duty * pct) / 100;
    ledc_set_duty(BACKLIGHT_LEDC_MODE, BACKLIGHT_LEDC_CHANNEL, duty);
    ledc_update_duty(BACKLIGHT_LEDC_MODE, BACKLIGHT_LEDC_CHANNEL);
}

// ---------------------------------------------------------------------------
// Display: ST77922 over QSPI
// ---------------------------------------------------------------------------
static lv_disp_t *display_init(esp_lcd_touch_handle_t *out_touch_handle)
{
    ESP_LOGI(TAG, "Init QSPI bus for display");
    const spi_bus_config_t buscfg = ST77922_PANEL_BUS_QSPI_CONFIG(
        BOARD_LCD_SCLK, BOARD_LCD_D0, BOARD_LCD_D1, BOARD_LCD_D2, BOARD_LCD_D3,
        BOARD_LCD_H_RES * 80 * sizeof(uint16_t));
    ESP_ERROR_CHECK(spi_bus_initialize(LCD_SPI_HOST, &buscfg, SPI_DMA_CH_AUTO));

    ESP_LOGI(TAG, "Install panel IO (QSPI)");
    esp_lcd_panel_io_handle_t io_handle = NULL;
    const esp_lcd_panel_io_spi_config_t io_config =
        ST77922_PANEL_IO_QSPI_CONFIG(BOARD_LCD_CS, NULL, NULL);
    ESP_ERROR_CHECK(esp_lcd_new_panel_io_spi((esp_lcd_spi_bus_handle_t)LCD_SPI_HOST, &io_config, &io_handle));

    ESP_LOGI(TAG, "Install ST77922 panel driver");
    esp_lcd_panel_handle_t panel_handle = NULL;
    const st77922_vendor_config_t vendor_config = {
        .flags = { .use_qspi_interface = 1 },
    };
    const esp_lcd_panel_dev_config_t panel_config = {
        .reset_gpio_num = BOARD_LCD_RST, // -1: reset shared with EN, power-on reset only
        .rgb_ele_order = LCD_RGB_ELEMENT_ORDER_RGB,
        .bits_per_pixel = 16,
        .vendor_config = (void *)&vendor_config,
    };
    ESP_ERROR_CHECK(esp_lcd_new_panel_st77922(io_handle, &panel_config, &panel_handle));
    ESP_ERROR_CHECK(esp_lcd_panel_reset(panel_handle));
    ESP_ERROR_CHECK(esp_lcd_panel_init(panel_handle));
    ESP_ERROR_CHECK(esp_lcd_panel_disp_on_off(panel_handle, true));

    backlight_init();
    board_set_backlight_pct(100);

    ESP_LOGI(TAG, "Init LVGL port");
    const lvgl_port_cfg_t lvgl_cfg = ESP_LVGL_PORT_INIT_CONFIG();
    ESP_ERROR_CHECK(lvgl_port_init(&lvgl_cfg));

    const lvgl_port_display_cfg_t disp_cfg = {
        .io_handle = io_handle,
        .panel_handle = panel_handle,
        .buffer_size = BOARD_LCD_H_RES * 60,
        .double_buffer = true,
        .hres = BOARD_LCD_H_RES,
        .vres = BOARD_LCD_V_RES,
        .monochrome = false,
        .color_format = LV_COLOR_FORMAT_RGB565,
        .rotation = {
            .swap_xy = false,
            .mirror_x = false,
            .mirror_y = false,
        },
        .flags = {
            .buff_dma = false,
            .buff_spiram = true,
            .sw_rotate = false,
        },
    };
    lv_disp_t *disp = lvgl_port_add_disp(&disp_cfg);

    // ---- Touch (I2C, CST816S-class controller — see board_config.h note) ----
    ESP_LOGI(TAG, "Init I2C bus for touch");
    const i2c_config_t i2c_conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = BOARD_TOUCH_SDA,
        .scl_io_num = BOARD_TOUCH_SCL,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = 400000,
    };
    ESP_ERROR_CHECK(i2c_param_config(BOARD_TOUCH_I2C_PORT, &i2c_conf));
    ESP_ERROR_CHECK(i2c_driver_install(BOARD_TOUCH_I2C_PORT, i2c_conf.mode, 0, 0, 0));

    esp_lcd_panel_io_handle_t touch_io_handle = NULL;
    const esp_lcd_panel_io_i2c_config_t touch_io_config = ESP_LCD_TOUCH_IO_I2C_CST816S_CONFIG();
    esp_err_t touch_io_err = esp_lcd_new_panel_io_i2c((esp_lcd_i2c_bus_handle_t)BOARD_TOUCH_I2C_PORT,
                                                       &touch_io_config, &touch_io_handle);

    esp_lcd_touch_handle_t touch_handle = NULL;
    if (touch_io_err == ESP_OK) {
        const esp_lcd_touch_config_t touch_cfg = {
            .x_max = BOARD_LCD_H_RES,
            .y_max = BOARD_LCD_V_RES,
            .rst_gpio_num = BOARD_TOUCH_RST,
            .int_gpio_num = BOARD_TOUCH_INT,
            .levels = { .reset = 0, .interrupt = 0 },
            .flags = { .swap_xy = 0, .mirror_x = 0, .mirror_y = 0 },
        };
        esp_err_t touch_err = esp_lcd_touch_new_i2c_cst816s(touch_io_handle, &touch_cfg, &touch_handle);
        if (touch_err == ESP_OK) {
            const lvgl_port_touch_cfg_t lvgl_touch_cfg = {
                .disp = disp,
                .handle = touch_handle,
            };
            lvgl_port_add_touch(&lvgl_touch_cfg);
            ESP_LOGI(TAG, "Touch initialized");
        } else {
            ESP_LOGW(TAG, "Touch controller did not respond as CST816S (err=0x%x). "
                          "Screen will still work, touch input will not. "
                          "See the note in board_config.h.", touch_err);
        }
    } else {
        ESP_LOGW(TAG, "Could not create touch panel IO (err=0x%x)", touch_io_err);
    }

    if (out_touch_handle) {
        *out_touch_handle = touch_handle;
    }
    return disp;
}

// ---------------------------------------------------------------------------
// Addressable RGB status LED (IO40)
// ---------------------------------------------------------------------------
static void rgb_led_init(void)
{
    led_strip_config_t strip_config = {
        .strip_gpio_num = BOARD_RGB_LED_GPIO,
        .max_leds = 1,
    };
    led_strip_rmt_config_t rmt_config = {
        .resolution_hz = 10 * 1000 * 1000,
    };
    ESP_ERROR_CHECK(led_strip_new_rmt_device(&strip_config, &rmt_config, &g_rgb_led));
    led_strip_clear(g_rgb_led);
}

// ---------------------------------------------------------------------------
// Wi-Fi (station mode, scanning only — not auto-connected anywhere)
// ---------------------------------------------------------------------------
void board_wifi_init(void)
{
    static bool done = false;
    if (done) return;
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());
    done = true;
}

// ---------------------------------------------------------------------------
// BLE (NimBLE host, scan/observer role only)
// ---------------------------------------------------------------------------
static void ble_host_task(void *param)
{
    nimble_port_run();
    nimble_port_freertos_deinit();
}

static void ble_on_sync(void)
{
    ble_hs_id_infer_auto(0, NULL);
}

void board_ble_init(void)
{
    static bool done = false;
    if (done) return;
    ESP_ERROR_CHECK(nimble_port_init());
    ble_hs_cfg.sync_cb = ble_on_sync;
    nimble_port_freertos_init(ble_host_task);
    done = true;
}

void app_main(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());

    esp_lcd_touch_handle_t touch_handle = NULL;
    s_disp = display_init(&touch_handle);
    rgb_led_init();

    lvgl_port_lock(0);
    ui_menu_create(s_disp);
    lvgl_port_unlock();

    ESP_LOGI(TAG, "Multitool UI running");
}
