#include "ui_menu.h"

static lv_obj_t *s_menu_screen = NULL;

static void btn_event_cb(lv_event_t *e)
{
    void (*handler)(void) = (void (*)(void))lv_event_get_user_data(e);
    if (handler) handler();
}

static lv_obj_t *make_tile(lv_obj_t *parent, const char *title, const char *subtitle, void (*on_click)(void))
{
    lv_obj_t *btn = lv_btn_create(parent);
    lv_obj_set_size(btn, 140, 100);
    lv_obj_set_style_radius(btn, 14, 0);
    lv_obj_set_style_bg_color(btn, lv_color_hex(0x1b2430), 0);
    lv_obj_add_event_cb(btn, btn_event_cb, LV_EVENT_CLICKED, (void *)on_click);

    lv_obj_t *lbl = lv_label_create(btn);
    lv_label_set_text(lbl, title);
    lv_obj_set_style_text_font(lbl, &lv_font_montserrat_18, 0);
    lv_obj_align(lbl, LV_ALIGN_TOP_MID, 0, 14);

    lv_obj_t *sub = lv_label_create(btn);
    lv_label_set_text(sub, subtitle);
    lv_obj_set_style_text_color(sub, lv_color_hex(0x8ca0b3), 0);
    lv_obj_align(sub, LV_ALIGN_BOTTOM_MID, 0, -10);

    return btn;
}

void ui_menu_create(lv_disp_t *disp)
{
    (void)disp;
    s_menu_screen = lv_obj_create(NULL);
    lv_obj_set_style_bg_color(s_menu_screen, lv_color_hex(0x0d1117), 0);

    lv_obj_t *title = lv_label_create(s_menu_screen);
    lv_label_set_text(title, "ESP32-S3 Multitool");
    lv_obj_set_style_text_font(title, &lv_font_montserrat_22, 0);
    lv_obj_set_style_text_color(title, lv_color_white(), 0);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 10);

    lv_obj_t *grid = lv_obj_create(s_menu_screen);
    lv_obj_remove_style_all(grid);
    lv_obj_set_size(grid, lv_pct(100), lv_pct(80));
    lv_obj_align(grid, LV_ALIGN_BOTTOM_MID, 0, -8);
    lv_obj_set_flex_flow(grid, LV_FLEX_FLOW_ROW_WRAP);
    lv_obj_set_flex_align(grid, LV_FLEX_ALIGN_SPACE_EVENLY, LV_FLEX_ALIGN_SPACE_EVENLY, LV_FLEX_ALIGN_CENTER);

    make_tile(grid, LV_SYMBOL_WIFI " Wi-Fi", "Scan networks", ui_wifi_screen_show);
    make_tile(grid, LV_SYMBOL_BLUETOOTH " BLE", "Scan devices", ui_ble_screen_show);
    make_tile(grid, LV_SYMBOL_IMAGE " RGB LED", "Color control", ui_led_screen_show);
    make_tile(grid, LV_SYMBOL_BELL " Clock", "Time / NTP", ui_clock_screen_show);
    make_tile(grid, LV_SYMBOL_SETTINGS " Settings", "Brightness", ui_settings_screen_show);

    lv_disp_load_scr(s_menu_screen);
}

void ui_menu_show(void)
{
    lv_disp_load_scr(s_menu_screen);
}
