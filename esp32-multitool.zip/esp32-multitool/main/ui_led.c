#include "led_strip.h"
#include "ui_menu.h"

static lv_obj_t *s_screen = NULL;
static lv_obj_t *s_preview = NULL;
static uint8_t s_r = 255, s_g = 0, s_b = 0;

static void apply_color(void)
{
    if (g_rgb_led) {
        led_strip_set_pixel(g_rgb_led, 0, s_r, s_g, s_b);
        led_strip_refresh(g_rgb_led);
    }
    lv_obj_set_style_bg_color(s_preview, lv_color_make(s_r, s_g, s_b), 0);
}

static void slider_cb(lv_event_t *e)
{
    lv_obj_t *slider = lv_event_get_target(e);
    int32_t val = lv_slider_get_value(slider);
    uint8_t *target = (uint8_t *)lv_event_get_user_data(e);
    *target = (uint8_t)val;
    apply_color();
}

static void make_slider(lv_obj_t *parent, const char *label_text, uint8_t *target, lv_color_t track_color)
{
    lv_obj_t *label = lv_label_create(parent);
    lv_label_set_text(label, label_text);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);

    lv_obj_t *slider = lv_slider_create(parent);
    lv_obj_set_width(slider, lv_pct(85));
    lv_slider_set_range(slider, 0, 255);
    lv_slider_set_value(slider, *target, LV_ANIM_OFF);
    lv_obj_set_style_bg_color(slider, track_color, LV_PART_INDICATOR);
    lv_obj_add_event_cb(slider, slider_cb, LV_EVENT_VALUE_CHANGED, target);
}

static void back_btn_cb(lv_event_t *e) { (void)e; ui_menu_show(); }

void ui_led_screen_show(void)
{
    if (!s_screen) {
        s_screen = lv_obj_create(NULL);
        lv_obj_set_style_bg_color(s_screen, lv_color_hex(0x0d1117), 0);
        lv_obj_set_flex_flow(s_screen, LV_FLEX_FLOW_COLUMN);
        lv_obj_set_flex_align(s_screen, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
        lv_obj_set_style_pad_row(s_screen, 14, 0);
        lv_obj_set_style_pad_top(s_screen, 50, 0);

        lv_obj_t *back = lv_btn_create(s_screen);
        lv_obj_align(back, LV_ALIGN_TOP_LEFT, 8, 8);
        lv_obj_add_event_cb(back, back_btn_cb, LV_EVENT_CLICKED, NULL);
        lv_obj_t *back_lbl = lv_label_create(back);
        lv_label_set_text(back_lbl, LV_SYMBOL_LEFT " Menu");

        s_preview = lv_obj_create(s_screen);
        lv_obj_set_size(s_preview, 90, 90);
        lv_obj_set_style_radius(s_preview, LV_RADIUS_CIRCLE, 0);
        lv_obj_set_style_border_width(s_preview, 2, 0);
        lv_obj_set_style_border_color(s_preview, lv_color_white(), 0);

        make_slider(s_screen, "Red", &s_r, lv_color_hex(0xff4444));
        make_slider(s_screen, "Green", &s_g, lv_color_hex(0x44ff44));
        make_slider(s_screen, "Blue", &s_b, lv_color_hex(0x4477ff));

        apply_color();
    }
    lv_disp_load_scr(s_screen);
}
