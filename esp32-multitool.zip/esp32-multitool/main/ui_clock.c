#include <time.h>
#include <sys/time.h>
#include "esp_sntp.h"
#include "ui_menu.h"

static lv_obj_t *s_screen = NULL;
static lv_obj_t *s_time_label = NULL;
static lv_obj_t *s_date_label = NULL;
static lv_obj_t *s_status_label = NULL;
static lv_timer_t *s_tick_timer = NULL;
static bool s_sntp_started = false;

static void tick_cb(lv_timer_t *t)
{
    (void)t;
    time_t now;
    struct tm tm_info;
    time(&now);
    localtime_r(&now, &tm_info);

    char tbuf[16], dbuf[32];
    strftime(tbuf, sizeof(tbuf), "%H:%M:%S", &tm_info);
    strftime(dbuf, sizeof(dbuf), "%A, %d %B %Y", &tm_info);
    lv_label_set_text(s_time_label, tbuf);
    lv_label_set_text(s_date_label, dbuf);
}

static void sync_btn_cb(lv_event_t *e)
{
    (void)e;
    board_wifi_init();
    if (!s_sntp_started) {
        esp_sntp_setoperatingmode(ESP_SNTP_OPMODE_POLL);
        esp_sntp_setservername(0, "pool.ntp.org");
        esp_sntp_init();
        s_sntp_started = true;
    }
    lv_label_set_text(s_status_label,
                       "Connect to Wi-Fi in your router/phone hotspot first;\n"
                       "time syncs automatically once online.");
}

static void back_btn_cb(lv_event_t *e) { (void)e; ui_menu_show(); }

void ui_clock_screen_show(void)
{
    if (!s_screen) {
        s_screen = lv_obj_create(NULL);
        lv_obj_set_style_bg_color(s_screen, lv_color_hex(0x0d1117), 0);

        lv_obj_t *back = lv_btn_create(s_screen);
        lv_obj_align(back, LV_ALIGN_TOP_LEFT, 8, 8);
        lv_obj_add_event_cb(back, back_btn_cb, LV_EVENT_CLICKED, NULL);
        lv_obj_t *back_lbl = lv_label_create(back);
        lv_label_set_text(back_lbl, LV_SYMBOL_LEFT " Menu");

        s_time_label = lv_label_create(s_screen);
        lv_obj_set_style_text_font(s_time_label, &lv_font_montserrat_22, 0);
        lv_obj_set_style_text_color(s_time_label, lv_color_white(), 0);
        lv_obj_align(s_time_label, LV_ALIGN_CENTER, 0, -40);

        s_date_label = lv_label_create(s_screen);
        lv_obj_set_style_text_color(s_date_label, lv_color_hex(0x8ca0b3), 0);
        lv_obj_align(s_date_label, LV_ALIGN_CENTER, 0, 0);

        lv_obj_t *sync = lv_btn_create(s_screen);
        lv_obj_align(sync, LV_ALIGN_CENTER, 0, 50);
        lv_obj_add_event_cb(sync, sync_btn_cb, LV_EVENT_CLICKED, NULL);
        lv_obj_t *sync_lbl = lv_label_create(sync);
        lv_label_set_text(sync_lbl, "Sync time over Wi-Fi");

        s_status_label = lv_label_create(s_screen);
        lv_obj_set_style_text_color(s_status_label, lv_color_hex(0x8ca0b3), 0);
        lv_label_set_long_mode(s_status_label, LV_LABEL_LONG_WRAP);
        lv_obj_set_width(s_status_label, lv_pct(85));
        lv_obj_set_style_text_align(s_status_label, LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_align(s_status_label, LV_ALIGN_CENTER, 0, 100);

        s_tick_timer = lv_timer_create(tick_cb, 1000, NULL);
    }
    lv_disp_load_scr(s_screen);
}
