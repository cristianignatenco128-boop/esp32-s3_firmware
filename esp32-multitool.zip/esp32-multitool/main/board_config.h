#pragma once

// LCDWIKI ES3C35P — ESP32-S3-N16R8, 320x480 ST77922 over QSPI, capacitive touch.
// Pin numbers below come from the vendor's official "ESP32-S3 pin allocation"
// table (lcdwiki.com/3.5inch_ESP32-S3_Display). If your board revision differs,
// this is the only file you should need to touch.

// ---- Display (QSPI) ----
#define BOARD_LCD_CS       10
#define BOARD_LCD_SCLK     12
#define BOARD_LCD_D0       11
#define BOARD_LCD_D1       13
#define BOARD_LCD_D2       14
#define BOARD_LCD_D3       9
#define BOARD_LCD_RST      -1   // LCD reset is wired to EN (shared with MCU reset); no GPIO control
#define BOARD_LCD_BL       41   // backlight, active high (driven via LEDC PWM for brightness control)

#define BOARD_LCD_H_RES    320
#define BOARD_LCD_V_RES    480

// ---- Capacitive touch (I2C) ----
// NOTE: the vendor docs confirm a capacitive touch IC is present and on this
// I2C bus, but do not name the exact part number. This project defaults to
// CST816S/CST820-compatible register access (the common choice on this class
// of LCDWIKI/QDtech boards). If touch does not respond, check the silkscreen
// on the touch FPC or the schematic PDF linked from the product wiki page,
// and swap the touch driver component in ui list if it's a different chip.
#define BOARD_TOUCH_SDA    38   // shared with audio codec + expansion I2C
#define BOARD_TOUCH_SCL    39
#define BOARD_TOUCH_RST    48
#define BOARD_TOUCH_INT    47
#define BOARD_TOUCH_I2C_PORT 0

// ---- Addressable RGB status LED ----
#define BOARD_RGB_LED_GPIO 40

// ---- Misc ----
#define BOARD_BATTERY_ADC_GPIO 8   // battery voltage sense (ADC1 channel, GPIO8)
