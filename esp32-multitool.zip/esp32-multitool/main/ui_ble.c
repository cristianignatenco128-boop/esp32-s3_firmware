#include <string.h>
#include "esp_log.h"
#include "host/ble_hs.h"
#include "host/ble_gap.h"
#include "ui_menu.h"

static const char *TAG = "ui_ble";

static lv_obj_t *s_screen = NULL;
static lv_obj_t *s_list = NULL;
static lv_obj_t *s_status = NULL;
static bool s_scanning = false;

static void add_row(const char *addr_str, int8_t rssi, const char *name)
{
    char line[80];
    snprintf(line, sizeof(line), "%s   %4ddBm   %s", addr_str, rssi, name ? name : "(no name)");
    lv_obj_t *btn = lv_list_add_btn(s_list, LV_SYMBOL_BLUETOOTH, line);
    lv_obj_set_style_text_font(btn, &lv_font_montserrat_14, 0);
}

static void parse_name_from_adv(const struct ble_hs_adv_fields *fields, char *out, size_t out_len)
{
    if (fields->name_len > 0) {
        size_t n = fields->name_len < (out_len - 1) ? fields->name_len : (out_len - 1);
        memcpy(out, fields->name, n);
        out[n] = '\0';
    } else {
        out[0] = '\0';
    }
}

static int ble_gap_event_cb(struct ble_gap_event *event, void *arg)
{
    if (event->type != BLE_GAP_EVENT_DISC) {
        if (event->type == BLE_GAP_EVENT_DISC_COMPLETE) {
            s_scanning = false;
            lv_label_set_text(s_status, "Scan complete");
        }
        return 0;
    }

    struct ble_hs_adv_fields fields;
    ble_hs_adv_parse_fields(&fields, event->disc.data, event->disc.length_data);

    char addr_str[18];
    const uint8_t *a = event->disc.addr.val;
    snprintf(addr_str, sizeof(addr_str), "%02X:%02X:%02X:%02X:%02X:%02X",
             a[5], a[4], a[3], a[2], a[1], a[0]);

    char name[32];
    parse_name_from_adv(&fields, name, sizeof(name));

    add_row(addr_str, event->disc.rssi, name[0] ? name : NULL);
    return 0;
}

static void start_scan(void)
{
    board_ble_init();
    lv_obj_clean(s_list);
    lv_label_set_text(s_status, "Scanning (10s)...");

    struct ble_gap_disc_params disc_params = {
        .passive = 1,
        .itvl = 0x50,
        .window = 0x30,
        .filter_duplicates = 1,
    };
    s_scanning = true;
    int rc = ble_gap_disc(BLE_OWN_ADDR_PUBLIC, 10000 /* ms */, &disc_params, ble_gap_event_cb, NULL);
    if (rc != 0) {
        lv_label_set_text_fmt(s_status, "Scan start failed (rc=%d)", rc);
        s_scanning = false;
    }
}

static void scan_btn_cb(lv_event_t *e) { (void)e; start_scan(); }
static void back_btn_cb(lv_event_t *e) { (void)e; ui_menu_show(); }

void ui_ble_screen_show(void)
{
    if (!s_screen) {
        s_screen = lv_obj_create(NULL);
        lv_obj_set_style_bg_color(s_screen, lv_color_hex(0x0d1117), 0);

        lv_obj_t *back = lv_btn_create(s_screen);
        lv_obj_align(back, LV_ALIGN_TOP_LEFT, 8, 8);
        lv_obj_add_event_cb(back, back_btn_cb, LV_EVENT_CLICKED, NULL);
        lv_obj_t *back_lbl = lv_label_create(back);
        lv_label_set_text(back_lbl, LV_SYMBOL_LEFT " Menu");

        lv_obj_t *scan = lv_btn_create(s_screen);
        lv_obj_align(scan, LV_ALIGN_TOP_RIGHT, -8, 8);
        lv_obj_add_event_cb(scan, scan_btn_cb, LV_EVENT_CLICKED, NULL);
        lv_obj_t *scan_lbl = lv_label_create(scan);
        lv_label_set_text(scan_lbl, LV_SYMBOL_REFRESH " Scan");

        s_status = lv_label_create(s_screen);
        lv_obj_set_style_text_color(s_status, lv_color_white(), 0);
        lv_obj_align(s_status, LV_ALIGN_TOP_MID, 0, 16);
        lv_label_set_text(s_status, "Tap Scan to search");

        s_list = lv_list_create(s_screen);
        lv_obj_set_size(s_list, lv_pct(96), lv_pct(76));
        lv_obj_align(s_list, LV_ALIGN_BOTTOM_MID, 0, -8);
    }
    lv_disp_load_scr(s_screen);
}
